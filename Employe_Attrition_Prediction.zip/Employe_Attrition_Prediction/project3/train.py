import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import joblib

def train_model(data_path):
    # 1. Load Data
    hr = pd.read_csv(data_path)
    
    # RENAME SECTION: This ensures column names match the 'cols' list below
    # We map common variations to the name we want to use
    hr = hr.rename(columns={
        'sales': 'department',
        'last_evaluation': 'last_evaluation_rating'  # Matches your cols list
    })

    # 2. Preprocessing
    # Combine departments as done in the notebook
    hr['department'] = np.where(hr['department'] == 'support', 'technical', hr['department'])
    hr['department'] = np.where(hr['department'] == 'IT', 'technical', hr['department'])

    # Create Dummy Variables
    cat_vars = ['department', 'salary']
    for var in cat_vars:
        # Use dtype=int to ensure 0/1 instead of True/False
        cat_list = pd.get_dummies(hr[var], prefix=var, dtype=int)
        hr = hr.join(cat_list)
    
    # 3. Feature Selection
    # These must exist in hr.columns exactly as written
    cols = ['satisfaction_level', 'last_evaluation_rating', 'time_spend_company', 
            'Work_accident', 'promotion_last_5years', 'department_RandD', 
            'department_hr', 'department_management', 'salary_high', 'salary_low']
    
    # Safety Check: Print columns if it fails again
    try:
        X = hr[cols]
    except KeyError as e:
        print(f"Error: {e}")
        print("The available columns in your file are:", hr.columns.tolist())
        return

    y = hr['left']

    # 4. Split and Train
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)
    
    print("Training Random Forest Model...")
    rf = RandomForestClassifier(n_estimators=100, random_state=0)
    rf.fit(X_train, y_train)
    
    accuracy = rf.score(X_test, y_test)
    print(f"Model Training Complete. Accuracy: {accuracy:.4f}")

    # 5. Save Model and Metadata
    joblib.dump(rf, 'attrition_model.pkl')
    joblib.dump(cols, 'model_columns.pkl')
    print("Model saved as 'attrition_model.pkl'")

if __name__ == "__main__":
    train_model('HR_comma_sep.csv')