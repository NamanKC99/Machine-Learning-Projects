import pandas as pd
import joblib

def predict_attrition(sample_data):
    # 1. Load Model and Columns
    try:
        model = joblib.load('attrition_model.pkl')
        model_columns = joblib.load('model_columns.pkl')
    except:
        print("Error: Model files not found. Run train.py first.")
        return

    # 2. Prepare Input Data
    # Ensure the input matches the expected features
    input_df = pd.DataFrame([sample_data])
    
    # Reindex to match training columns (fills missing dummy columns with 0)
    input_df = input_df.reindex(columns=model_columns, fill_value=0)

    # 3. Predict
    prediction = model.predict(input_df)
    probability = model.predict_proba(input_df)[0][1]

    result = "Leave" if prediction[0] == 1 else "Stay"
    print(f"\nPrediction: Employee is likely to {result}")
    print(f"Probability of Leaving: {probability:.2%}")

if __name__ == "__main__":
    # Example Sample Data (Change these values to test)
    example_employee = {
        'satisfaction_level': 0.38,
        'last_evaluation_rating': 0.53,
        'time_spend_company': 3,
        'Work_accident': 0,
        'promotion_last_5years': 0,
        'department_hr': 1,      # Employee is in HR
        'salary_low': 1          # Employee has low salary
    }
    
    predict_attrition(example_employee)