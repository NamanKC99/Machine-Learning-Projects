import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
import pickle

def train_model():
    # Load data
    data = pd.read_csv('AQI-and-Lat-Long-of-Countries.csv')

    # Preprocessing
    data = data.dropna()
    data.columns = [col.strip().lower() for col in data.columns]

    # Define features and target
    X = data[['co aqi value', 'ozone aqi value', 'no2 aqi value', 'pm2.5 aqi value']]
    y = data['aqi value']

    # Split data
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Train model
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    # Save model
    with open('model.pickle', 'wb') as file:
        pickle.dump(model, file)

    print("Model trained and saved to model.pickle")

if __name__ == '__main__':
    train_model()
