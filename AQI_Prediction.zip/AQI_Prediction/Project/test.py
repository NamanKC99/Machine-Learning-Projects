import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import pickle
import matplotlib.pyplot as plt
import seaborn as sns

def test_model():
    # Load data
    data = pd.read_csv('AQI-and-Lat-Long-of-Countries.csv')

    # Preprocessing
    data = data.dropna()
    data.columns = [col.strip().lower() for col in data.columns]

    # Define features and target
    X = data[['co aqi value', 'ozone aqi value', 'no2 aqi value', 'pm2.5 aqi value']]
    y = data['aqi value']

    # Split data (use the same random_state as in train.py to ensure consistent test set)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Load the trained model
    with open('model.pickle', 'rb') as file:
        model = pickle.load(file)

    # Make predictions
    y_pred = model.predict(X_test)

    # Evaluate the model
    print("Model Evaluation:")
    print("Mean Absolute Error:", mean_absolute_error(y_test, y_pred))
    print("Mean Squared Error:", mean_squared_error(y_test, y_pred))
    print("R2 Score:", r2_score(y_test, y_pred))

    # Plot actual vs. predicted AQI
    plt.figure(figsize=(10, 6))
    plt.plot(y_test.values, label='Actual AQI')
    plt.plot(y_pred, label='Predicted AQI', alpha=0.7)
    plt.title('Actual vs Predicted AQI')
    plt.xlabel('Sample Index')
    plt.ylabel('AQI Value')
    plt.legend()
    plt.show()

if __name__ == '__main__':
    test_model()
