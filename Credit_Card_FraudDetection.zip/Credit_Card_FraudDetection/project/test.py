import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, matthews_corrcoef, confusion_matrix
import joblib
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset
data = pd.read_csv("creditcard.csv") # Assuming creditcard.csv is in the same directory

# Separate features (X) and target (Y)
X = data.drop(['Class'], axis=1)
Y = data["Class"]

# Recreate the test set using the exact same split as in train.py
# We only need xTest and yTest for evaluation here
xTrain, xTest, yTrain, yTest = train_test_split(X, Y, test_size=0.2, random_state=42)

# Load the trained model
model = joblib.load('random_forest_model.pkl')

# Make predictions on the test set
yPred = model.predict(xTest)

# Calculate and print evaluation metrics
print("Evaluation Metrics for the Random Forest Classifier:")

acc = accuracy_score(yTest, yPred)
print("Accuracy: {:.4f}".format(acc))

prec = precision_score(yTest, yPred)
print("Precision: {:.4f}".format(prec))

rec = recall_score(yTest, yPred)
print("Recall: {:.4f}".format(rec))

f1 = f1_score(yTest, yPred)
print("F1-Score: {:.4f}".format(f1))

MCC = matthews_corrcoef(yTest, yPred)
print("Matthews Correlation Coefficient: {:.4f}".format(MCC))

# Generate and display confusion matrix
LABELS = ['Normal', 'Fraud']
conf_matrix = confusion_matrix(yTest, yPred)
plt.figure(figsize=(8, 6))
sns.heatmap(conf_matrix, xticklabels=LABELS, yticklabels=LABELS, annot=True, fmt="d", cmap="Blues")
plt.title("Confusion Matrix")
plt.ylabel('True class')
plt.xlabel('Predicted class')
plt.show()