import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import joblib
import os

# 1. Handle File Paths for Windows
# Ensure the CSV is in the same folder as your script or provide the full Windows path
csv_path = "creditcard.csv" 

if not os.path.exists(csv_path):
    print(f"Error: Could not find {csv_path}. Please check the file location.")
else:
    # 2. Load the dataset
    print("Loading data...")
    data = pd.read_csv(csv_path)

    # 3. Separate features (X) and target (Y)
    X = data.drop(['Class'], axis=1)
    Y = data["Class"]

    # 4. Split the data
    xTrain, xTest, yTrain, yTest = train_test_split(X, Y, test_size=0.2, random_state=42)

    # 5. Initialize and Train
    print("Training model (this may take a minute)...")
    rfc = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1) # added n_jobs for speed
    rfc.fit(xTrain, yTrain)

    # 6. Save the model
    joblib.dump(rfc, 'random_forest_model.pkl')
    print("Success: Model trained and saved as 'random_forest_model.pkl'")